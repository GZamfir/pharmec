Joomla.submitbutton = function(task)
{
    if (task == '')
    {
        return false;
    }

}